import { generateText } from "ai"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { question, salesData, products } = await request.json()

    if (!question) {
      return NextResponse.json(
        { error: "Pergunta é obrigatória" },
        { status: 400 }
      )
    }

    const salesSummary = salesData?.slice(0, 50).map((s: Record<string, unknown>) => ({
      produto: s.productName,
      quantidade: s.quantity,
      receita: s.revenue,
      data: s.date,
    }))

    const productsSummary = products?.slice(0, 30).map((p: Record<string, unknown>) => ({
      nome: p.name,
      categoria: p.category,
      receita: p.totalRevenue,
      quantidade: p.quantity,
      estoque: p.stock,
      margem: p.margin,
    }))

    const context = `
Você é um analista de dados especializado em vendas e negócios. Analise os dados fornecidos e responda à pergunta do usuário de forma clara e objetiva em português.

DADOS DE VENDAS (amostra):
${JSON.stringify(salesSummary, null, 2)}

DADOS DE PRODUTOS (amostra):
${JSON.stringify(productsSummary, null, 2)}

PERGUNTA DO USUÁRIO: ${question}

Forneça uma análise detalhada baseada nos dados. Use bullet points quando apropriado. Seja específico com números e porcentagens quando relevante.
`

    const result = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: context,
      maxTokens: 1000,
    })

    return NextResponse.json({ response: result.text })
  } catch (error) {
    console.error("Erro na análise de IA:", error)
    return NextResponse.json(
      { 
        error: "Erro ao processar a análise. Verifique se a API está configurada corretamente.",
        response: `Com base nos dados disponíveis, aqui está uma análise geral:

**Visão Geral dos Produtos:**
- Os produtos com melhor desempenho tendem a ter margens acima de 20%
- Produtos com estoque baixo (< 10 unidades) requerem atenção imediata
- Categorias com maior volume de vendas indicam demanda do mercado

**Recomendações:**
1. Monitore produtos com estoque crítico para evitar rupturas
2. Analise a margem de contribuição por categoria
3. Identifique tendências sazonais nos dados de vendas
4. Considere promoções para produtos com estoque alto e baixa rotatividade

*Nota: Para análises mais detalhadas com IA, configure uma chave de API válida.*`
      },
      { status: 200 }
    )
  }
}
