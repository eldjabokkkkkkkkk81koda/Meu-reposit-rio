"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import {
  TrendingUp,
  BarChart3,
  Sparkles,
  Upload,
  Shield,
  Zap,
  CheckCircle2,
  ArrowRight,
} from "lucide-react"

const features = [
  {
    icon: BarChart3,
    title: "Análise Visual",
    description: "Gráficos interativos e dashboards que mostram suas métricas de vendas em tempo real.",
  },
  {
    icon: Sparkles,
    title: "Insights com IA",
    description: "Inteligência artificial identifica padrões, tendências e oportunidades automaticamente.",
  },
  {
    icon: Upload,
    title: "Upload Simples",
    description: "Importe seus dados de vendas via CSV de forma rápida e segura.",
  },
  {
    icon: Shield,
    title: "Alertas Inteligentes",
    description: "Receba notificações sobre estoque baixo, quedas nas vendas e oportunidades.",
  },
]

const benefits = [
  "Visualize todas as suas vendas em um só lugar",
  "Identifique produtos com melhor e pior desempenho",
  "Monitore estoque e evite rupturas",
  "Receba recomendações personalizadas de IA",
  "Exporte relatórios profissionais",
  "Acesse de qualquer dispositivo",
]

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <TrendingUp className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-lg font-semibold">SalesAI</span>
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link href="/login">Entrar</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Começar Grátis</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 py-20 text-center">
        <div className="mx-auto max-w-3xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-muted/50 px-4 py-1.5 text-sm">
            <Zap className="h-4 w-4 text-primary" />
            <span>Análise de vendas potencializada por IA</span>
          </div>
          <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
            Transforme seus dados de vendas em{" "}
            <span className="text-primary">insights acionáveis</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground">
            SalesAI analisa automaticamente seus dados de vendas e estoque,
            identifica tendências e gera recomendações inteligentes para
            aumentar sua receita.
          </p>
          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <Button size="lg" asChild>
              <Link href="/register">
                Começar Gratuitamente
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/login">Ver Demonstração</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-t border-border bg-muted/30 py-20">
        <div className="mx-auto max-w-6xl px-4">
          <div className="text-center">
            <h2 className="text-3xl font-bold">Tudo que você precisa</h2>
            <p className="mt-2 text-muted-foreground">
              Ferramentas poderosas para análise completa das suas vendas
            </p>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature) => (
              <Card key={feature.title}>
                <CardContent className="pt-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mt-4 font-semibold">{feature.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20">
        <div className="mx-auto max-w-6xl px-4">
          <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 className="text-3xl font-bold">
                Por que escolher o SalesAI?
              </h2>
              <p className="mt-4 text-muted-foreground">
                Nossa plataforma foi desenvolvida para ajudar empresas de todos
                os tamanhos a entender melhor seus dados de vendas e tomar
                decisões mais inteligentes.
              </p>
              <ul className="mt-8 space-y-4">
                {benefits.map((benefit) => (
                  <li key={benefit} className="flex items-center gap-3">
                    <CheckCircle2 className="h-5 w-5 flex-shrink-0 text-success" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-8">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="h-3 w-3 rounded-full bg-destructive" />
                  <div className="h-3 w-3 rounded-full bg-warning" />
                  <div className="h-3 w-3 rounded-full bg-success" />
                </div>
                <div className="space-y-3">
                  <div className="h-8 w-full rounded bg-muted" />
                  <div className="grid grid-cols-4 gap-3">
                    <div className="h-24 rounded bg-primary/20" />
                    <div className="h-24 rounded bg-primary/30" />
                    <div className="h-24 rounded bg-primary/40" />
                    <div className="h-24 rounded bg-primary/50" />
                  </div>
                  <div className="h-32 w-full rounded bg-muted" />
                  <div className="grid grid-cols-2 gap-3">
                    <div className="h-20 rounded bg-muted" />
                    <div className="h-20 rounded bg-muted" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border bg-muted/30 py-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <h2 className="text-3xl font-bold">
            Pronto para começar?
          </h2>
          <p className="mt-4 text-muted-foreground">
            Crie sua conta gratuita e comece a analisar suas vendas em minutos.
          </p>
          <Button size="lg" className="mt-8" asChild>
            <Link href="/register">
              Criar Conta Grátis
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="mx-auto max-w-6xl px-4">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <TrendingUp className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-semibold">SalesAI</span>
            </div>
            <p className="text-sm text-muted-foreground">
              2024 SalesAI. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
