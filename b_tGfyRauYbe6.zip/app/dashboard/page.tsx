"use client"

import { useStore } from "@/lib/store"
import { KPICards } from "@/components/dashboard/kpi-cards"
import { Charts } from "@/components/dashboard/charts"
import { AIInsights } from "@/components/dashboard/ai-insights"
import { AlertsList } from "@/components/dashboard/alerts-list"
import { calculateKPIs } from "@/lib/analytics"
import { generateInsights } from "@/lib/insights"
import { useMemo, useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const { sales, stock, alerts, markAlertAsRead, setInsights, insights } = useStore()
  const [isLoading, setIsLoading] = useState(true)

  const kpiData = useMemo(() => {
    if (!sales || sales.length === 0) return null
    return calculateKPIs(sales)
  }, [sales])

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 500)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (sales.length > 0 && stock.length > 0) {
      const newInsights = generateInsights(sales, stock)
      setInsights(newInsights)
    }
  }, [sales, stock, setInsights])

  const hasData = sales.length > 0

  if (!hasData && !isLoading) {
    return (
      <div className="flex h-full flex-col items-center justify-center">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
            <Upload className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-2xl font-bold">Bem-vindo ao SalesAI</h1>
          <p className="mt-2 text-muted-foreground">
            Para começar a usar o dashboard, faça upload de um arquivo CSV com
            seus dados de vendas.
          </p>
          <Button asChild className="mt-6">
            <Link href="/dashboard/upload">
              <Upload className="mr-2 h-4 w-4" />
              Fazer Upload
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          Visão geral das suas vendas e insights gerados por IA.
        </p>
      </div>

      <KPICards data={kpiData} isLoading={isLoading} />

      <Charts
        salesData={sales}
        products={stock}
        isLoading={isLoading}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <AIInsights insights={insights} isLoading={isLoading} />
        <AlertsList
          alerts={alerts}
          onDismiss={markAlertAsRead}
        />
      </div>
    </div>
  )
}
