"use client"

import { useState } from "react"
import { useStore } from "@/lib/store"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { AIInsights } from "@/components/dashboard/ai-insights"
import { Sparkles, Send, Upload, Loader2 } from "lucide-react"
import Link from "next/link"
import ReactMarkdown from "react-markdown"

export default function AIAnalysisPage() {
  const { sales, stock, insights } = useStore()
  const [question, setQuestion] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [response, setResponse] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const hasData = sales && sales.length > 0

  const handleAskQuestion = async () => {
    if (!question.trim()) return

    setIsLoading(true)
    setError(null)
    setResponse(null)

    try {
      const res = await fetch("/api/ai-analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          salesData: sales.slice(0, 100),
          products: stock.slice(0, 50),
        }),
      })

      if (!res.ok) {
        throw new Error("Erro ao processar pergunta")
      }

      const data = await res.json()
      setResponse(data.response)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro desconhecido")
    } finally {
      setIsLoading(false)
    }
  }

  if (!hasData) {
    return (
      <div className="flex h-full flex-col items-center justify-center">
        <div className="max-w-md text-center">
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
            <Sparkles className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-2xl font-bold">Análise com IA</h1>
          <p className="mt-2 text-muted-foreground">
            Para usar a análise com IA, primeiro faça upload dos seus dados de vendas.
          </p>
          <Button asChild className="mt-6">
            <Link href="/dashboard/upload">
              <Upload className="mr-2 h-4 w-4" />
              Fazer Upload
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Análise com IA</h1>
        <p className="text-muted-foreground">
          Faça perguntas sobre seus dados e receba análises inteligentes.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Pergunte à IA
              </CardTitle>
              <CardDescription>
                Faça perguntas sobre vendas, tendências, produtos e previsões.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Ex: Quais são os produtos com melhor desempenho? Quais tendências você identifica nas vendas?"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                rows={4}
              />
              <Button
                onClick={handleAskQuestion}
                disabled={isLoading || !question.trim()}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analisando...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Enviar Pergunta
                  </>
                )}
              </Button>

              {error && (
                <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
                  {error}
                </div>
              )}

              {response && (
                <div className="rounded-lg border bg-muted/30 p-4">
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <ReactMarkdown>{response}</ReactMarkdown>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Sugestões de Perguntas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {[
                  "Quais produtos estão com estoque baixo?",
                  "Qual foi a tendência de vendas este mês?",
                  "Quais categorias têm melhor margem?",
                  "Que produtos devo promover?",
                ].map((suggestion) => (
                  <Button
                    key={suggestion}
                    variant="outline"
                    size="sm"
                    onClick={() => setQuestion(suggestion)}
                    className="text-xs"
                  >
                    {suggestion}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <AIInsights insights={insights} />
      </div>
    </div>
  )
}
