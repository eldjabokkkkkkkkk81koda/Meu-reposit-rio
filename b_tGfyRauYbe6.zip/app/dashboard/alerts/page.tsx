"use client"

import { useStore } from "@/lib/store"
import { AlertsList } from "@/components/dashboard/alerts-list"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bell, CheckCheck } from "lucide-react"

export default function AlertsPage() {
  const { alerts, markAlertAsRead } = useStore()

  const unreadCount = alerts ? alerts.filter((a) => !a.read).length : 0

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Alertas</h1>
          <p className="text-muted-foreground">
            {unreadCount > 0
              ? `Você tem ${unreadCount} alerta${unreadCount > 1 ? "s" : ""} não lido${unreadCount > 1 ? "s" : ""}.`
              : "Todos os alertas foram lidos."}
          </p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" onClick={() => alerts?.forEach(a => markAlertAsRead(a.id))}>
            <CheckCheck className="mr-2 h-4 w-4" />
            Marcar todos como lidos
          </Button>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <AlertsList
            alerts={alerts || []}
            onDismiss={markAlertAsRead}
            showAll
          />
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Estatísticas</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Total de alertas</span>
                <span className="font-medium">{alerts?.length || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Não lidos</span>
                <span className="font-medium text-destructive">{unreadCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Críticos</span>
                <span className="font-medium">
                  {alerts?.filter((a) => a.severity === "critical").length || 0}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Avisos</span>
                <span className="font-medium">
                  {alerts?.filter((a) => a.severity === "warning").length || 0}
                </span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Configurações de Alertas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Configure quais tipos de alertas você deseja receber nas configurações do sistema.
              </p>
              <Button variant="outline" className="mt-4 w-full" asChild>
                <a href="/dashboard/settings">Configurar</a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
