"use client"

import { useStore } from "@/lib/store"
import { ProductTable } from "@/components/dashboard/product-table"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"
import Link from "next/link"

export default function ProductsPage() {
  const { stock } = useStore()

  if (!stock || stock.length === 0) {
    return (
      <div className="flex h-full flex-col items-center justify-center">
        <div className="max-w-md text-center">
          <h1 className="text-2xl font-bold">Nenhum produto encontrado</h1>
          <p className="mt-2 text-muted-foreground">
            Faça upload de um arquivo CSV para visualizar seus produtos.
          </p>
          <Button asChild className="mt-6">
            <Link href="/dashboard/upload">
              <Upload className="mr-2 h-4 w-4" />
              Fazer Upload
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Produtos</h1>
        <p className="text-muted-foreground">
          Gerencie e analise o desempenho dos seus produtos.
        </p>
      </div>

      <ProductTable products={stock} />
    </div>
  )
}
