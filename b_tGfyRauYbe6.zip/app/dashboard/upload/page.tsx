"use client"

import { CSVUpload } from "@/components/dashboard/csv-upload"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2, FileSpreadsheet, BarChart3, Sparkles } from "lucide-react"

export default function UploadPage() {
  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Upload de Dados</h1>
        <p className="text-muted-foreground">
          Importe seus dados de vendas ou estoque para começar a análise.
        </p>
      </div>

      <CSVUpload />

      <Card>
        <CardHeader>
          <CardTitle>Como funciona</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <FileSpreadsheet className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-3 font-medium">1. Upload</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Envie seu arquivo CSV, TXT ou Excel
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <BarChart3 className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-3 font-medium">2. Processamento</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Analisamos automaticamente seus dados
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-3 font-medium">3. Insights</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Receba insights e recomendações com IA
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Exemplos de Arquivos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="mb-2 text-sm font-medium">Dados de Vendas (CSV/TXT/Excel)</h4>
            <div className="overflow-x-auto rounded-lg border bg-muted/30">
              <pre className="p-4 text-xs">
{`data,produto,categoria,quantidade,valor,canal
01/01/2024,Camiseta Básica,Vestuário,5,299.50,Loja Online
01/01/2024,Calça Jeans,Vestuário,2,379.80,Loja Física
02/01/2024,Tênis Running,Calçados,3,899.70,Loja Online`}
              </pre>
            </div>
          </div>

          <div>
            <h4 className="mb-2 text-sm font-medium">Dados de Estoque (CSV/TXT/Excel)</h4>
            <div className="overflow-x-auto rounded-lg border bg-muted/30">
              <pre className="p-4 text-xs">
{`sku,nome,categoria,quantidade,preco,estoque_minimo,fornecedor
SKU-001,Camiseta Básica,Vestuário,500,59.90,50,Fornecedor A
SKU-002,Calça Jeans,Vestuário,200,189.90,30,Fornecedor B
SKU-003,Tênis Running,Calçados,100,299.90,20,Fornecedor C`}
              </pre>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Suporta vírgula (,), ponto e vírgula (;) ou tab como separador</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Formatos de data: DD/MM/AAAA, AAAA-MM-DD</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Valores podem usar vírgula ou ponto decimal</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Detecta automaticamente o tipo de dados</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
