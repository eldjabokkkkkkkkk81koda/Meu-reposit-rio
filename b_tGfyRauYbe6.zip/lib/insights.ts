import type { SaleRecord, ProductStock, KPIData, AIInsight } from './types'
import { formatCurrency, formatPercentage, calculateKPIs } from './analytics'

// Função simplificada para uso no dashboard
export function generateInsights(
  sales: SaleRecord[],
  stock: ProductStock[]
): AIInsight[] {
  if (sales.length === 0) return []
  const kpis = calculateKPIs(sales)
  return generateAutoInsights(sales, stock, kpis)
}

export function generateAutoInsights(
  sales: SaleRecord[], 
  stock: ProductStock[], 
  kpis: KPIData
): AIInsight[] {
  const insights: AIInsight[] = []
  const now = new Date().toISOString()
  
  // Análise de tendência de vendas
  if (kpis.salesByPeriod.length >= 2) {
    const recentPeriods = kpis.salesByPeriod.slice(-3)
    const trend = analyzeTrend(recentPeriods.map(p => p.revenue))
    
    if (trend === 'up') {
      insights.push({
        id: `trend-up-${Date.now()}`,
        type: 'trend',
        title: 'Tendência de Crescimento Detectada',
        description: `Suas vendas mostram uma tendência de crescimento consistente nos últimos períodos. A receita aumentou ${formatPercentage(kpis.growthRate)} recentemente.`,
        confidence: 0.85,
        impact: 'high',
        actionable: true,
        suggestedActions: [
          'Aumente o estoque dos produtos mais vendidos',
          'Considere expandir sua equipe de vendas',
          'Avalie oportunidades de investimento em marketing',
        ],
        timestamp: now,
      })
    } else if (trend === 'down') {
      insights.push({
        id: `trend-down-${Date.now()}`,
        type: 'trend',
        title: 'Atenção: Tendência de Queda',
        description: `As vendas mostram uma tendência de queda. A variação foi de ${formatPercentage(kpis.growthRate)} no período recente.`,
        confidence: 0.82,
        impact: 'high',
        actionable: true,
        suggestedActions: [
          'Revise sua estratégia de preços',
          'Analise a concorrência',
          'Considere promoções para produtos com baixa saída',
          'Avalie a satisfação dos clientes',
        ],
        timestamp: now,
      })
    }
  }
  
  // Análise de produtos de alto desempenho
  if (kpis.topProducts.length > 0) {
    const topProduct = kpis.topProducts[0]
    if (topProduct.percentage > 25) {
      insights.push({
        id: `top-product-${Date.now()}`,
        type: 'recommendation',
        title: 'Produto Destaque Identificado',
        description: `"${topProduct.product}" representa ${topProduct.percentage.toFixed(1)}% da sua receita total (${formatCurrency(topProduct.revenue)}). Este é seu produto mais importante.`,
        confidence: 0.95,
        impact: 'high',
        actionable: true,
        suggestedActions: [
          'Garanta estoque adequado deste produto',
          'Considere criar bundles ou kits com ele',
          'Analise o que torna este produto tão popular',
        ],
        relatedData: { product: topProduct.product, revenue: topProduct.revenue },
        timestamp: now,
      })
    }
  }
  
  // Análise de diversificação
  if (kpis.salesByCategory.length > 0) {
    const topCategory = kpis.salesByCategory[0]
    if (topCategory.percentage > 50) {
      insights.push({
        id: `diversification-${Date.now()}`,
        type: 'recommendation',
        title: 'Oportunidade de Diversificação',
        description: `${topCategory.percentage.toFixed(1)}% das vendas vêm da categoria "${topCategory.category}". Diversificar pode reduzir riscos.`,
        confidence: 0.78,
        impact: 'medium',
        actionable: true,
        suggestedActions: [
          'Explore produtos complementares em outras categorias',
          'Crie promoções cruzadas entre categorias',
          'Analise o potencial de crescimento de categorias menores',
        ],
        timestamp: now,
      })
    }
  }
  
  // Análise de estoque crítico
  const criticalStock = stock.filter(p => p.currentStock <= p.minStock)
  if (criticalStock.length > 0) {
    insights.push({
      id: `stock-critical-${Date.now()}`,
      type: 'anomaly',
      title: `${criticalStock.length} Produto${criticalStock.length > 1 ? 's' : ''} com Estoque Crítico`,
      description: `Os seguintes produtos precisam de reposição urgente: ${criticalStock.slice(0, 3).map(p => p.name).join(', ')}${criticalStock.length > 3 ? ` e mais ${criticalStock.length - 3}` : ''}.`,
      confidence: 1.0,
      impact: 'high',
      actionable: true,
      suggestedActions: [
        'Faça pedido de reposição imediatamente',
        'Configure alertas automáticos de estoque',
        'Revise os níveis mínimos de estoque',
      ],
      relatedData: { products: criticalStock.map(p => p.name) },
      timestamp: now,
    })
  }
  
  // Análise de ticket médio
  if (kpis.averageTicket > 0) {
    if (kpis.averageTicket < 150) {
      insights.push({
        id: `ticket-analysis-${Date.now()}`,
        type: 'recommendation',
        title: 'Oportunidade de Aumentar Ticket Médio',
        description: `Seu ticket médio atual é ${formatCurrency(kpis.averageTicket)}. Estratégias de upselling podem aumentar a receita significativamente.`,
        confidence: 0.75,
        impact: 'medium',
        actionable: true,
        suggestedActions: [
          'Ofereça produtos complementares no checkout',
          'Crie pacotes com desconto progressivo',
          'Implemente programa de fidelidade com benefícios',
        ],
        timestamp: now,
      })
    } else if (kpis.averageTicket > 500) {
      insights.push({
        id: `ticket-high-${Date.now()}`,
        type: 'trend',
        title: 'Ticket Médio Elevado',
        description: `Seu ticket médio de ${formatCurrency(kpis.averageTicket)} está acima da média. Continue investindo em produtos de maior valor agregado.`,
        confidence: 0.85,
        impact: 'low',
        actionable: false,
        timestamp: now,
      })
    }
  }
  
  // Previsão simples
  if (kpis.salesByPeriod.length >= 3) {
    const recentRevenues = kpis.salesByPeriod.slice(-3).map(p => p.revenue)
    const avgGrowth = calculateAverageGrowth(recentRevenues)
    const predictedRevenue = recentRevenues[recentRevenues.length - 1] * (1 + avgGrowth / 100)
    
    insights.push({
      id: `prediction-${Date.now()}`,
      type: 'prediction',
      title: 'Previsão para o Próximo Período',
      description: `Com base na tendência atual, a receita esperada para o próximo período é de aproximadamente ${formatCurrency(predictedRevenue)}.`,
      confidence: 0.65,
      impact: 'medium',
      actionable: false,
      relatedData: { predictedRevenue, avgGrowth },
      timestamp: now,
    })
  }
  
  // Ordenar por impacto e confiança
  return insights.sort((a, b) => {
    const impactOrder = { high: 0, medium: 1, low: 2 }
    if (impactOrder[a.impact] !== impactOrder[b.impact]) {
      return impactOrder[a.impact] - impactOrder[b.impact]
    }
    return b.confidence - a.confidence
  })
}

function analyzeTrend(values: number[]): 'up' | 'down' | 'stable' {
  if (values.length < 2) return 'stable'
  
  let increases = 0
  let decreases = 0
  
  for (let i = 1; i < values.length; i++) {
    const change = ((values[i] - values[i - 1]) / values[i - 1]) * 100
    if (change > 5) increases++
    else if (change < -5) decreases++
  }
  
  if (increases > decreases) return 'up'
  if (decreases > increases) return 'down'
  return 'stable'
}

function calculateAverageGrowth(values: number[]): number {
  if (values.length < 2) return 0
  
  let totalGrowth = 0
  for (let i = 1; i < values.length; i++) {
    totalGrowth += ((values[i] - values[i - 1]) / values[i - 1]) * 100
  }
  
  return totalGrowth / (values.length - 1)
}
