import * as XLSX from "xlsx"
import type { SaleRecord, StockItem } from "./types"

export type FileType = "csv" | "txt" | "xlsx" | "xls"

export function detectFileType(filename: string): FileType | null {
  const ext = filename.split(".").pop()?.toLowerCase()
  console.log("[v0] detectFileType:", { filename, ext })
  if (ext === "csv") return "csv"
  if (ext === "txt") return "txt"
  if (ext === "xlsx") return "xlsx"
  if (ext === "xls") return "xls"
  // Fallback: try to detect from content later, default to csv for text files
  return null
}

export function detectFileTypeFromMime(mimeType: string): FileType | null {
  console.log("[v0] detectFileTypeFromMime:", mimeType)
  if (mimeType === "text/csv" || mimeType === "application/csv") return "csv"
  if (mimeType === "text/plain") return "txt"
  if (mimeType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") return "xlsx"
  if (mimeType === "application/vnd.ms-excel") return "xls"
  return null
}

export function getSupportedExtensions(): string[] {
  return [".csv", ".txt", ".xlsx", ".xls"]
}

export function getSupportedMimeTypes(): string {
  return ".csv,.txt,.xlsx,.xls,text/csv,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
}

async function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => resolve(e.target?.result as string)
    reader.onerror = reject
    reader.readAsText(file)
  })
}

async function readFileAsArrayBuffer(file: File): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => resolve(e.target?.result as ArrayBuffer)
    reader.onerror = reject
    reader.readAsArrayBuffer(file)
  })
}

function parseDelimitedText(content: string, delimiter: string = ","): string[][] {
  const lines = content.trim().split(/\r?\n/)
  return lines.map((line) => {
    const result: string[] = []
    let current = ""
    let inQuotes = false

    for (let i = 0; i < line.length; i++) {
      const char = line[i]
      if (char === '"') {
        inQuotes = !inQuotes
      } else if (char === delimiter && !inQuotes) {
        result.push(current.trim())
        current = ""
      } else {
        current += char
      }
    }
    result.push(current.trim())
    return result
  })
}

function detectDelimiter(content: string): string {
  const firstLine = content.split(/\r?\n/)[0] || ""
  const delimiters = [",", ";", "\t", "|"]
  let bestDelimiter = ","
  let maxCount = 0

  for (const delimiter of delimiters) {
    const count = (firstLine.match(new RegExp(delimiter === "\t" ? "\\t" : delimiter, "g")) || []).length
    if (count > maxCount) {
      maxCount = count
      bestDelimiter = delimiter
    }
  }

  return bestDelimiter
}

async function parseExcelFile(file: File): Promise<string[][]> {
  const buffer = await readFileAsArrayBuffer(file)
  const workbook = XLSX.read(buffer, { type: "array" })
  const firstSheetName = workbook.SheetNames[0]
  const worksheet = workbook.Sheets[firstSheetName]
  const data = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 })
  return data as string[][]
}

export async function parseFile(file: File): Promise<string[][]> {
  console.log("[v0] parseFile:", { name: file.name, type: file.type, size: file.size })
  
  let fileType = detectFileType(file.name)
  
  // Fallback to mime type detection
  if (!fileType) {
    fileType = detectFileTypeFromMime(file.type)
  }
  
  // Final fallback: treat as CSV if it looks like text
  if (!fileType && (file.type.startsWith("text/") || file.type === "" || file.type === "application/octet-stream")) {
    console.log("[v0] Fallback to CSV for text-like file")
    fileType = "csv"
  }

  if (!fileType) {
    throw new Error(`Tipo de arquivo não suportado: ${file.name} (${file.type})`)
  }

  console.log("[v0] Detected file type:", fileType)

  if (fileType === "xlsx" || fileType === "xls") {
    return parseExcelFile(file)
  }

  const content = await readFileAsText(file)
  const delimiter = detectDelimiter(content)
  console.log("[v0] Detected delimiter:", delimiter === "\t" ? "TAB" : delimiter)
  return parseDelimitedText(content, delimiter)
}

function normalizeHeader(header: string): string {
  return header
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_|_$/g, "")
}

function findColumnIndex(headers: string[], possibleNames: string[]): number {
  const normalizedHeaders = headers.map(normalizeHeader)
  for (const name of possibleNames) {
    const normalized = normalizeHeader(name)
    const index = normalizedHeaders.findIndex((h) => h.includes(normalized) || normalized.includes(h))
    if (index !== -1) return index
  }
  return -1
}

export function detectDataType(headers: string[]): "sales" | "stock" | "unknown" {
  const normalizedHeaders = headers.map(normalizeHeader)
  const headerString = normalizedHeaders.join(" ")

  const salesIndicators = ["data", "date", "valor", "value", "venda", "sale", "receita", "revenue", "quantidade", "quantity"]
  const stockIndicators = ["estoque", "stock", "quantidade", "quantity", "sku", "produto", "product", "preco", "price"]

  const salesScore = salesIndicators.filter((indicator) => headerString.includes(indicator)).length
  const stockScore = stockIndicators.filter((indicator) => headerString.includes(indicator)).length

  if (salesScore > stockScore && salesScore >= 2) return "sales"
  if (stockScore >= 2) return "stock"
  return "unknown"
}

export function parseSalesData(data: string[][]): SaleRecord[] {
  if (data.length < 2) return []

  const headers = data[0].map(String)
  const rows = data.slice(1)

  const dateCol = findColumnIndex(headers, ["data", "date", "data_venda", "sale_date", "dia", "day"])
  const productCol = findColumnIndex(headers, ["produto", "product", "item", "nome", "name", "descricao", "description"])
  const categoryCol = findColumnIndex(headers, ["categoria", "category", "tipo", "type", "grupo", "group"])
  const quantityCol = findColumnIndex(headers, ["quantidade", "quantity", "qty", "qtd", "unidades", "units"])
  const valueCol = findColumnIndex(headers, ["valor", "value", "preco", "price", "total", "receita", "revenue", "venda"])
  const channelCol = findColumnIndex(headers, ["canal", "channel", "origem", "source", "loja", "store"])

  return rows
    .filter((row) => row.some((cell) => cell && String(cell).trim()))
    .map((row, index) => {
      const parseNumber = (val: unknown): number => {
        if (val === undefined || val === null || val === "") return 0
        const str = String(val).replace(/[R$\s]/g, "").replace(",", ".")
        return parseFloat(str) || 0
      }

      const parseDate = (val: unknown): string => {
        if (!val) return new Date().toISOString().split("T")[0]
        const str = String(val)
        
        // Handle Excel serial date numbers
        if (/^\d+$/.test(str) && parseInt(str) > 40000) {
          const excelDate = new Date((parseInt(str) - 25569) * 86400 * 1000)
          return excelDate.toISOString().split("T")[0]
        }
        
        // Try to parse common date formats
        const formats = [
          /(\d{4})-(\d{2})-(\d{2})/, // YYYY-MM-DD
          /(\d{2})\/(\d{2})\/(\d{4})/, // DD/MM/YYYY
          /(\d{2})-(\d{2})-(\d{4})/, // DD-MM-YYYY
        ]
        
        for (const format of formats) {
          const match = str.match(format)
          if (match) {
            if (format === formats[0]) {
              return `${match[1]}-${match[2]}-${match[3]}`
            } else {
              return `${match[3]}-${match[2]}-${match[1]}`
            }
          }
        }
        
        return new Date().toISOString().split("T")[0]
      }

      return {
        id: `sale-${index + 1}`,
        date: parseDate(row[dateCol]),
        product: productCol >= 0 ? String(row[productCol] || "Produto") : "Produto",
        category: categoryCol >= 0 ? String(row[categoryCol] || "Geral") : "Geral",
        quantity: quantityCol >= 0 ? parseNumber(row[quantityCol]) : 1,
        value: valueCol >= 0 ? parseNumber(row[valueCol]) : 0,
        channel: channelCol >= 0 ? String(row[channelCol] || "Loja") : "Loja",
      }
    })
    .filter((record) => record.value > 0 || record.quantity > 0)
}

export function parseStockData(data: string[][]): StockItem[] {
  if (data.length < 2) return []

  const headers = data[0].map(String)
  const rows = data.slice(1)

  const skuCol = findColumnIndex(headers, ["sku", "codigo", "code", "id", "ref", "referencia"])
  const nameCol = findColumnIndex(headers, ["nome", "name", "produto", "product", "descricao", "description", "item"])
  const categoryCol = findColumnIndex(headers, ["categoria", "category", "tipo", "type", "grupo", "group"])
  const quantityCol = findColumnIndex(headers, ["quantidade", "quantity", "qty", "qtd", "estoque", "stock", "unidades"])
  const minStockCol = findColumnIndex(headers, ["minimo", "minimum", "min", "estoque_minimo", "min_stock", "ponto_reposicao"])
  const priceCol = findColumnIndex(headers, ["preco", "price", "valor", "value", "custo", "cost"])
  const supplierCol = findColumnIndex(headers, ["fornecedor", "supplier", "vendor", "fabricante", "manufacturer"])

  return rows
    .filter((row) => row.some((cell) => cell && String(cell).trim()))
    .map((row, index) => {
      const parseNumber = (val: unknown): number => {
        if (val === undefined || val === null || val === "") return 0
        const str = String(val).replace(/[R$\s]/g, "").replace(",", ".")
        return parseFloat(str) || 0
      }

      return {
        id: `stock-${index + 1}`,
        sku: skuCol >= 0 ? String(row[skuCol] || `SKU-${index + 1}`) : `SKU-${index + 1}`,
        name: nameCol >= 0 ? String(row[nameCol] || "Produto") : "Produto",
        category: categoryCol >= 0 ? String(row[categoryCol] || "Geral") : "Geral",
        quantity: quantityCol >= 0 ? parseNumber(row[quantityCol]) : 0,
        minStock: minStockCol >= 0 ? parseNumber(row[minStockCol]) : 10,
        price: priceCol >= 0 ? parseNumber(row[priceCol]) : 0,
        supplier: supplierCol >= 0 ? String(row[supplierCol] || "N/A") : "N/A",
      }
    })
}
