import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { SaleRecord, ProductStock, Alert, AIInsight, UserSettings } from './types'

interface AppState {
  // Dados
  sales: SaleRecord[]
  stock: ProductStock[]
  alerts: Alert[]
  insights: AIInsight[]
  
  // UI State
  sidebarCollapsed: boolean
  selectedPeriod: '7d' | '30d' | '90d' | '1y' | 'all'
  
  // Settings
  settings: UserSettings
  
  // Actions - Dados
  setSales: (sales: SaleRecord[]) => void
  addSales: (sales: SaleRecord[]) => void
  setStock: (stock: ProductStock[]) => void
  addStock: (stock: ProductStock[]) => void
  setAlerts: (alerts: Alert[]) => void
  markAlertAsRead: (id: string) => void
  setInsights: (insights: AIInsight[]) => void
  clearAllData: () => void
  
  // Actions - UI
  toggleSidebar: () => void
  setSelectedPeriod: (period: '7d' | '30d' | '90d' | '1y' | 'all') => void
  
  // Actions - Settings
  updateSettings: (settings: Partial<UserSettings>) => void
}

const defaultSettings: UserSettings = {
  theme: 'system',
  language: 'pt-BR',
  currency: 'BRL',
  notifications: {
    email: true,
    push: true,
    stockAlerts: true,
    salesAlerts: true,
    aiInsights: true,
  },
  dashboard: {
    defaultView: 'overview',
    refreshInterval: 30000,
    chartsPerPage: 4,
  },
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      // Estado inicial
      sales: [],
      stock: [],
      alerts: [],
      insights: [],
      sidebarCollapsed: false,
      selectedPeriod: '30d',
      settings: defaultSettings,
      
      // Actions - Dados
      setSales: (sales) => set({ sales }),
      addSales: (newSales) => set((state) => ({ 
        sales: [...state.sales, ...newSales] 
      })),
      setStock: (stock) => set({ stock }),
      addStock: (newStock) => set((state) => ({ 
        stock: [...state.stock, ...newStock] 
      })),
      setAlerts: (alerts) => set({ alerts }),
      markAlertAsRead: (id) => set((state) => ({
        alerts: state.alerts.map(alert => 
          alert.id === id ? { ...alert, read: true } : alert
        ),
      })),
      setInsights: (insights) => set({ insights }),
      clearAllData: () => set({ 
        sales: [], 
        stock: [], 
        alerts: [], 
        insights: [] 
      }),
      
      // Actions - UI
      toggleSidebar: () => set((state) => ({ 
        sidebarCollapsed: !state.sidebarCollapsed 
      })),
      setSelectedPeriod: (period) => set({ selectedPeriod: period }),
      
      // Actions - Settings
      updateSettings: (newSettings) => set((state) => ({
        settings: { ...state.settings, ...newSettings },
      })),
    }),
    {
      name: 'salesai-storage',
      partialize: (state) => ({
        sales: state.sales,
        stock: state.stock,
        sidebarCollapsed: state.sidebarCollapsed,
        selectedPeriod: state.selectedPeriod,
        settings: state.settings,
      }),
    }
  )
)

// Hook para dados filtrados por período
export function useFilteredSales() {
  const { sales, selectedPeriod } = useStore()
  
  const now = new Date()
  const filterDate = new Date()
  
  switch (selectedPeriod) {
    case '7d':
      filterDate.setDate(now.getDate() - 7)
      break
    case '30d':
      filterDate.setDate(now.getDate() - 30)
      break
    case '90d':
      filterDate.setDate(now.getDate() - 90)
      break
    case '1y':
      filterDate.setFullYear(now.getFullYear() - 1)
      break
    case 'all':
    default:
      return sales
  }
  
  return sales.filter(sale => new Date(sale.date) >= filterDate)
}
