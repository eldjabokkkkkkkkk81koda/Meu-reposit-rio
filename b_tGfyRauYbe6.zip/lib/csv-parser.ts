import Papa from 'papaparse'
import type { SaleRecord, ProductStock, UploadResult } from './types'

interface CSVRow {
  [key: string]: string
}

// Mapeamento de colunas comuns (PT-BR e EN)
const columnMappings: Record<string, string[]> = {
  id: ['id', 'codigo', 'código', 'code'],
  date: ['date', 'data', 'data_venda', 'sale_date'],
  product: ['product', 'produto', 'item', 'nome_produto', 'product_name'],
  category: ['category', 'categoria', 'tipo', 'type'],
  quantity: ['quantity', 'quantidade', 'qtd', 'qty', 'qtde'],
  unitPrice: ['unit_price', 'preco_unitario', 'preço_unitario', 'price', 'preco', 'preço', 'valor_unitario'],
  totalValue: ['total_value', 'valor_total', 'total', 'valor', 'value'],
  customer: ['customer', 'cliente', 'customer_name', 'nome_cliente'],
  region: ['region', 'regiao', 'região', 'area', 'estado', 'state'],
  seller: ['seller', 'vendedor', 'sales_rep', 'representante'],
  paymentMethod: ['payment_method', 'forma_pagamento', 'pagamento', 'payment'],
  status: ['status', 'situacao', 'situação', 'state'],
  // Para estoque
  name: ['name', 'nome', 'product_name', 'nome_produto'],
  currentStock: ['current_stock', 'estoque_atual', 'stock', 'estoque', 'quantidade'],
  minStock: ['min_stock', 'estoque_minimo', 'min', 'minimo', 'mínimo'],
  maxStock: ['max_stock', 'estoque_maximo', 'max', 'maximo', 'máximo'],
  unitCost: ['unit_cost', 'custo_unitario', 'cost', 'custo'],
  lastUpdate: ['last_update', 'ultima_atualizacao', 'última_atualização', 'updated_at'],
  supplier: ['supplier', 'fornecedor', 'vendor'],
}

function normalizeColumnName(column: string): string {
  return column.toLowerCase().trim().replace(/\s+/g, '_')
}

function findMappedColumn(headers: string[], targetField: string): string | null {
  const possibleNames = columnMappings[targetField] || [targetField]
  const normalizedHeaders = headers.map(h => normalizeColumnName(h))
  
  for (const name of possibleNames) {
    const index = normalizedHeaders.indexOf(normalizeColumnName(name))
    if (index !== -1) {
      return headers[index]
    }
  }
  return null
}

function parseNumber(value: string | undefined | null): number {
  if (!value) return 0
  const cleaned = value.toString()
    .replace(/[R$\s]/g, '')
    .replace(/\./g, '')
    .replace(',', '.')
  return parseFloat(cleaned) || 0
}

function parseDate(value: string | undefined | null): string {
  if (!value) return new Date().toISOString()
  
  // Tenta diferentes formatos de data
  const formats = [
    // DD/MM/YYYY
    /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/,
    // DD-MM-YYYY
    /^(\d{1,2})-(\d{1,2})-(\d{4})$/,
    // YYYY-MM-DD
    /^(\d{4})-(\d{1,2})-(\d{1,2})$/,
    // YYYY/MM/DD
    /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/,
  ]
  
  for (const format of formats) {
    const match = value.match(format)
    if (match) {
      if (match[1].length === 4) {
        // YYYY-MM-DD formato
        return new Date(parseInt(match[1]), parseInt(match[2]) - 1, parseInt(match[3])).toISOString()
      } else {
        // DD/MM/YYYY formato
        return new Date(parseInt(match[3]), parseInt(match[2]) - 1, parseInt(match[1])).toISOString()
      }
    }
  }
  
  // Tenta parse direto
  const parsed = new Date(value)
  return isNaN(parsed.getTime()) ? new Date().toISOString() : parsed.toISOString()
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}

export function parseCSVSales(csvContent: string): Promise<UploadResult> {
  return new Promise((resolve) => {
    Papa.parse<CSVRow>(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const errors: string[] = []
        const warnings: string[] = []
        const data: SaleRecord[] = []
        
        if (!results.data || results.data.length === 0) {
          resolve({
            success: false,
            recordsProcessed: 0,
            errors: ['Arquivo CSV vazio ou sem dados válidos'],
            warnings: [],
          })
          return
        }
        
        const headers = Object.keys(results.data[0] || {})
        
        // Mapear colunas
        const productCol = findMappedColumn(headers, 'product')
        const categoryCol = findMappedColumn(headers, 'category')
        const quantityCol = findMappedColumn(headers, 'quantity')
        const priceCol = findMappedColumn(headers, 'unitPrice')
        const totalCol = findMappedColumn(headers, 'totalValue')
        const dateCol = findMappedColumn(headers, 'date')
        
        if (!productCol) {
          warnings.push('Coluna de produto não encontrada, usando primeira coluna de texto')
        }
        
        results.data.forEach((row, index) => {
          try {
            const quantity = parseNumber(row[quantityCol || ''])
            const unitPrice = parseNumber(row[priceCol || ''])
            const total = parseNumber(row[totalCol || ''])
            
            const record: SaleRecord = {
              id: row[findMappedColumn(headers, 'id') || ''] || generateId(),
              date: parseDate(row[dateCol || '']),
              product: row[productCol || headers[0]] || `Produto ${index + 1}`,
              category: row[categoryCol || ''] || 'Geral',
              quantity: quantity || 1,
              unitPrice: unitPrice || (total / (quantity || 1)),
              totalValue: total || (quantity * unitPrice),
              customer: row[findMappedColumn(headers, 'customer') || ''],
              region: row[findMappedColumn(headers, 'region') || ''],
              seller: row[findMappedColumn(headers, 'seller') || ''],
              paymentMethod: row[findMappedColumn(headers, 'paymentMethod') || ''],
              status: (row[findMappedColumn(headers, 'status') || ''] as SaleRecord['status']) || 'completed',
            }
            
            // Validar registro
            if (record.totalValue <= 0 && record.quantity > 0 && record.unitPrice > 0) {
              record.totalValue = record.quantity * record.unitPrice
            }
            
            if (record.product && record.totalValue > 0) {
              data.push(record)
            } else {
              warnings.push(`Linha ${index + 2}: Dados incompletos, registro ignorado`)
            }
          } catch (error) {
            errors.push(`Linha ${index + 2}: Erro ao processar - ${error instanceof Error ? error.message : 'Erro desconhecido'}`)
          }
        })
        
        resolve({
          success: data.length > 0,
          recordsProcessed: data.length,
          errors,
          warnings,
          data,
        })
      },
      error: (error) => {
        resolve({
          success: false,
          recordsProcessed: 0,
          errors: [`Erro ao processar CSV: ${error.message}`],
          warnings: [],
        })
      },
    })
  })
}

export function parseCSVStock(csvContent: string): Promise<UploadResult> {
  return new Promise((resolve) => {
    Papa.parse<CSVRow>(csvContent, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const errors: string[] = []
        const warnings: string[] = []
        const data: ProductStock[] = []
        
        if (!results.data || results.data.length === 0) {
          resolve({
            success: false,
            recordsProcessed: 0,
            errors: ['Arquivo CSV vazio ou sem dados válidos'],
            warnings: [],
          })
          return
        }
        
        const headers = Object.keys(results.data[0] || {})
        
        results.data.forEach((row, index) => {
          try {
            const record: ProductStock = {
              id: row[findMappedColumn(headers, 'id') || ''] || generateId(),
              name: row[findMappedColumn(headers, 'name') || findMappedColumn(headers, 'product') || headers[0]] || `Produto ${index + 1}`,
              category: row[findMappedColumn(headers, 'category') || ''] || 'Geral',
              currentStock: parseNumber(row[findMappedColumn(headers, 'currentStock') || '']),
              minStock: parseNumber(row[findMappedColumn(headers, 'minStock') || '']) || 10,
              maxStock: parseNumber(row[findMappedColumn(headers, 'maxStock') || '']) || 1000,
              unitCost: parseNumber(row[findMappedColumn(headers, 'unitCost') || '']),
              lastUpdate: parseDate(row[findMappedColumn(headers, 'lastUpdate') || '']),
              supplier: row[findMappedColumn(headers, 'supplier') || ''],
            }
            
            if (record.name) {
              data.push(record)
            } else {
              warnings.push(`Linha ${index + 2}: Nome do produto ausente, registro ignorado`)
            }
          } catch (error) {
            errors.push(`Linha ${index + 2}: Erro ao processar - ${error instanceof Error ? error.message : 'Erro desconhecido'}`)
          }
        })
        
        resolve({
          success: data.length > 0,
          recordsProcessed: data.length,
          errors,
          warnings,
          data,
        })
      },
      error: (error) => {
        resolve({
          success: false,
          recordsProcessed: 0,
          errors: [`Erro ao processar CSV: ${error.message}`],
          warnings: [],
        })
      },
    })
  })
}

export function generateSampleCSV(type: 'sales' | 'stock'): string {
  if (type === 'sales') {
    return `data,produto,categoria,quantidade,preco_unitario,valor_total,cliente,regiao,vendedor
2024-01-15,Notebook Dell,Eletrônicos,2,3500.00,7000.00,João Silva,Sul,Maria Santos
2024-01-15,Mouse Logitech,Periféricos,5,150.00,750.00,Ana Costa,Sudeste,Pedro Lima
2024-01-16,Monitor LG,Eletrônicos,1,1200.00,1200.00,Carlos Souza,Norte,Maria Santos
2024-01-16,Teclado Microsoft,Periféricos,3,280.00,840.00,Julia Ferreira,Nordeste,Pedro Lima
2024-01-17,Impressora HP,Equipamentos,1,890.00,890.00,Roberto Alves,Centro-Oeste,Maria Santos`
  }
  
  return `nome,categoria,estoque_atual,estoque_minimo,estoque_maximo,custo_unitario,fornecedor
Notebook Dell,Eletrônicos,45,20,100,2800.00,Dell Brasil
Mouse Logitech,Periféricos,150,50,300,95.00,Logitech
Monitor LG,Eletrônicos,30,15,80,950.00,LG Electronics
Teclado Microsoft,Periféricos,80,30,200,180.00,Microsoft
Impressora HP,Equipamentos,25,10,50,720.00,HP Brasil`
}
