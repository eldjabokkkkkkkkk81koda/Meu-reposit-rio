import type { 
  SaleRecord, 
  ProductStock, 
  KPIData, 
  ProductPerformance, 
  CategorySales, 
  PeriodSales,
  Alert,
  ChartDataPoint 
} from './types'

export function calculateKPIs(sales: SaleRecord[], previousSales?: SaleRecord[]): KPIData {
  const totalSales = sales.length
  const totalRevenue = sales.reduce((sum, sale) => sum + sale.totalValue, 0)
  const averageTicket = totalSales > 0 ? totalRevenue / totalSales : 0
  
  // Calcular taxa de crescimento
  let growthRate = 0
  if (previousSales && previousSales.length > 0) {
    const previousRevenue = previousSales.reduce((sum, sale) => sum + sale.totalValue, 0)
    growthRate = previousRevenue > 0 
      ? ((totalRevenue - previousRevenue) / previousRevenue) * 100 
      : 0
  }
  
  // Top produtos por receita
  const productMap = new Map<string, { quantity: number; revenue: number }>()
  sales.forEach(sale => {
    const existing = productMap.get(sale.product) || { quantity: 0, revenue: 0 }
    productMap.set(sale.product, {
      quantity: existing.quantity + sale.quantity,
      revenue: existing.revenue + sale.totalValue,
    })
  })
  
  const topProducts: ProductPerformance[] = Array.from(productMap.entries())
    .map(([product, data]) => ({
      product,
      quantity: data.quantity,
      revenue: data.revenue,
      percentage: totalRevenue > 0 ? (data.revenue / totalRevenue) * 100 : 0,
    }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10)
  
  // Vendas por categoria
  const categoryMap = new Map<string, number>()
  sales.forEach(sale => {
    const existing = categoryMap.get(sale.category) || 0
    categoryMap.set(sale.category, existing + sale.totalValue)
  })
  
  const salesByCategory: CategorySales[] = Array.from(categoryMap.entries())
    .map(([category, total]) => ({
      category,
      total,
      percentage: totalRevenue > 0 ? (total / totalRevenue) * 100 : 0,
    }))
    .sort((a, b) => b.total - a.total)
  
  // Vendas por período (últimos 12 meses)
  const periodMap = new Map<string, { sales: number; revenue: number }>()
  sales.forEach(sale => {
    const date = new Date(sale.date)
    const period = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`
    const existing = periodMap.get(period) || { sales: 0, revenue: 0 }
    periodMap.set(period, {
      sales: existing.sales + 1,
      revenue: existing.revenue + sale.totalValue,
    })
  })
  
  const salesByPeriod: PeriodSales[] = Array.from(periodMap.entries())
    .map(([period, data]) => ({
      period,
      sales: data.sales,
      revenue: data.revenue,
    }))
    .sort((a, b) => a.period.localeCompare(b.period))
  
  return {
    totalSales,
    totalRevenue,
    averageTicket,
    conversionRate: 75, // Placeholder - seria calculado com dados de leads
    growthRate,
    topProducts,
    salesByCategory,
    salesByPeriod,
  }
}

export function generateStockAlerts(stock: ProductStock[]): Alert[] {
  const alerts: Alert[] = []
  const now = new Date().toISOString()
  
  stock.forEach(product => {
    // Alerta de estoque baixo
    if (product.currentStock <= product.minStock) {
      alerts.push({
        id: `stock-low-${product.id}`,
        type: product.currentStock === 0 ? 'danger' : 'warning',
        title: product.currentStock === 0 ? 'Estoque Zerado' : 'Estoque Baixo',
        message: `${product.name} está com apenas ${product.currentStock} unidades (mínimo: ${product.minStock})`,
        timestamp: now,
        read: false,
        data: { productId: product.id, currentStock: product.currentStock },
      })
    }
    
    // Alerta de excesso de estoque
    if (product.currentStock >= product.maxStock * 0.9) {
      alerts.push({
        id: `stock-high-${product.id}`,
        type: 'info',
        title: 'Estoque Alto',
        message: `${product.name} está com ${product.currentStock} unidades (máximo: ${product.maxStock})`,
        timestamp: now,
        read: false,
        data: { productId: product.id, currentStock: product.currentStock },
      })
    }
  })
  
  return alerts.sort((a, b) => {
    const priority = { danger: 0, warning: 1, info: 2, success: 3 }
    return priority[a.type] - priority[b.type]
  })
}

export function generateSalesAlerts(sales: SaleRecord[], kpis: KPIData): Alert[] {
  const alerts: Alert[] = []
  const now = new Date().toISOString()
  
  // Alerta de queda nas vendas
  if (kpis.growthRate < -10) {
    alerts.push({
      id: `sales-drop-${Date.now()}`,
      type: 'warning',
      title: 'Queda nas Vendas',
      message: `As vendas caíram ${Math.abs(kpis.growthRate).toFixed(1)}% em relação ao período anterior`,
      timestamp: now,
      read: false,
      data: { growthRate: kpis.growthRate },
    })
  }
  
  // Alerta de crescimento expressivo
  if (kpis.growthRate > 20) {
    alerts.push({
      id: `sales-growth-${Date.now()}`,
      type: 'success',
      title: 'Crescimento Expressivo',
      message: `As vendas cresceram ${kpis.growthRate.toFixed(1)}% em relação ao período anterior!`,
      timestamp: now,
      read: false,
      data: { growthRate: kpis.growthRate },
    })
  }
  
  // Alerta de ticket médio baixo
  if (kpis.averageTicket < 100) {
    alerts.push({
      id: `ticket-low-${Date.now()}`,
      type: 'info',
      title: 'Ticket Médio Baixo',
      message: `O ticket médio atual é de ${formatCurrency(kpis.averageTicket)}. Considere estratégias de upselling.`,
      timestamp: now,
      read: false,
      data: { averageTicket: kpis.averageTicket },
    })
  }
  
  return alerts
}

export function prepareChartData(sales: SaleRecord[]): {
  revenueByDay: ChartDataPoint[]
  salesByCategory: ChartDataPoint[]
  topProducts: ChartDataPoint[]
} {
  // Receita por dia (últimos 30 dias)
  const dayMap = new Map<string, number>()
  const thirtyDaysAgo = new Date()
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)
  
  sales
    .filter(sale => new Date(sale.date) >= thirtyDaysAgo)
    .forEach(sale => {
      const date = new Date(sale.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })
      const existing = dayMap.get(date) || 0
      dayMap.set(date, existing + sale.totalValue)
    })
  
  const revenueByDay: ChartDataPoint[] = Array.from(dayMap.entries())
    .map(([name, value]) => ({ name, value }))
    .slice(-30)
  
  // Vendas por categoria
  const categoryMap = new Map<string, number>()
  sales.forEach(sale => {
    const existing = categoryMap.get(sale.category) || 0
    categoryMap.set(sale.category, existing + sale.totalValue)
  })
  
  const salesByCategory: ChartDataPoint[] = Array.from(categoryMap.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
  
  // Top 5 produtos
  const productMap = new Map<string, number>()
  sales.forEach(sale => {
    const existing = productMap.get(sale.product) || 0
    productMap.set(sale.product, existing + sale.totalValue)
  })
  
  const topProducts: ChartDataPoint[] = Array.from(productMap.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5)
  
  return { revenueByDay, salesByCategory, topProducts }
}

// Utilitários de formatação
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value)
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('pt-BR').format(value)
}

export function formatPercentage(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).format(new Date(date))
}

export function formatDateTime(date: string | Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(date))
}

export function getRelativeTime(date: string | Date): string {
  const now = new Date()
  const target = new Date(date)
  const diffMs = now.getTime() - target.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)
  
  if (diffMins < 1) return 'Agora mesmo'
  if (diffMins < 60) return `Há ${diffMins} minuto${diffMins > 1 ? 's' : ''}`
  if (diffHours < 24) return `Há ${diffHours} hora${diffHours > 1 ? 's' : ''}`
  if (diffDays < 7) return `Há ${diffDays} dia${diffDays > 1 ? 's' : ''}`
  return formatDate(date)
}
