// Tipos principais do sistema

export interface SaleRecord {
  id: string
  date: string
  product: string
  category: string
  quantity: number
  unitPrice: number
  totalValue: number
  customer?: string
  region?: string
  seller?: string
  paymentMethod?: string
  status?: 'completed' | 'pending' | 'cancelled'
}

export interface ProductStock {
  id: string
  name: string
  category: string
  currentStock: number
  minStock: number
  maxStock: number
  unitCost: number
  lastUpdate: string
  supplier?: string
}

export interface KPIData {
  totalSales: number
  totalRevenue: number
  averageTicket: number
  conversionRate: number
  growthRate: number
  topProducts: ProductPerformance[]
  salesByCategory: CategorySales[]
  salesByPeriod: PeriodSales[]
}

export interface ProductPerformance {
  product: string
  quantity: number
  revenue: number
  percentage: number
}

export interface CategorySales {
  category: string
  total: number
  percentage: number
}

export interface PeriodSales {
  period: string
  sales: number
  revenue: number
}

export interface Alert {
  id: string
  type: 'warning' | 'danger' | 'info' | 'success'
  title: string
  message: string
  timestamp: string
  read: boolean
  data?: Record<string, unknown>
}

export interface AIInsight {
  id: string
  type: 'trend' | 'anomaly' | 'recommendation' | 'prediction'
  title: string
  description: string
  confidence: number
  impact: 'high' | 'medium' | 'low'
  actionable: boolean
  suggestedActions?: string[]
  relatedData?: Record<string, unknown>
  timestamp: string
}

export interface DashboardData {
  kpis: KPIData
  alerts: Alert[]
  insights: AIInsight[]
  recentSales: SaleRecord[]
  stockAlerts: ProductStock[]
}

export interface ChartDataPoint {
  name: string
  value: number
  [key: string]: string | number
}

export interface DateRange {
  from: Date
  to: Date
}

export interface FilterOptions {
  dateRange?: DateRange
  categories?: string[]
  products?: string[]
  regions?: string[]
  status?: string[]
}

export interface UserSettings {
  theme: 'light' | 'dark' | 'system'
  language: 'pt-BR' | 'en-US'
  currency: 'BRL' | 'USD'
  notifications: {
    email: boolean
    push: boolean
    stockAlerts: boolean
    salesAlerts: boolean
    aiInsights: boolean
  }
  dashboard: {
    defaultView: 'overview' | 'sales' | 'stock'
    refreshInterval: number
    chartsPerPage: number
  }
}

export interface UploadResult {
  success: boolean
  recordsProcessed: number
  errors: string[]
  warnings: string[]
  data?: SaleRecord[] | ProductStock[]
}

export interface APIResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}
