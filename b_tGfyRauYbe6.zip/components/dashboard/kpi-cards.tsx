"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package,
  ShoppingCart,
  Percent,
} from "lucide-react"
import type { KPIData } from "@/lib/types"

interface KPICardsProps {
  data: KPIData | null
  isLoading?: boolean
}

export function KPICards({ data, isLoading }: KPICardsProps) {
  const cards = [
    {
      title: "Receita Total",
      value: data?.totalRevenue ?? 0,
      change: data?.revenueGrowth ?? 0,
      format: "currency",
      icon: DollarSign,
    },
    {
      title: "Total de Vendas",
      value: data?.totalSales ?? 0,
      change: data?.salesGrowth ?? 0,
      format: "number",
      icon: ShoppingCart,
    },
    {
      title: "Produtos Ativos",
      value: data?.activeProducts ?? 0,
      change: 0,
      format: "number",
      icon: Package,
    },
    {
      title: "Margem Média",
      value: data?.averageMargin ?? 0,
      change: data?.marginChange ?? 0,
      format: "percent",
      icon: Percent,
    },
  ]

  const formatValue = (value: number, format: string) => {
    switch (format) {
      case "currency":
        return new Intl.NumberFormat("pt-BR", {
          style: "currency",
          currency: "BRL",
        }).format(value)
      case "percent":
        return `${value.toFixed(1)}%`
      default:
        return new Intl.NumberFormat("pt-BR").format(value)
    }
  }

  if (isLoading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <div className="h-4 w-24 rounded bg-muted" />
              <div className="h-8 w-8 rounded bg-muted" />
            </CardHeader>
            <CardContent>
              <div className="h-8 w-32 rounded bg-muted" />
              <div className="mt-2 h-4 w-20 rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {card.title}
            </CardTitle>
            <div className="rounded-lg bg-primary/10 p-2">
              <card.icon className="h-4 w-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatValue(card.value, card.format)}
            </div>
            {card.change !== 0 && (
              <div
                className={cn(
                  "mt-1 flex items-center gap-1 text-sm",
                  card.change > 0 ? "text-success" : "text-destructive"
                )}
              >
                {card.change > 0 ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                <span>
                  {card.change > 0 ? "+" : ""}
                  {card.change.toFixed(1)}% vs. período anterior
                </span>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
