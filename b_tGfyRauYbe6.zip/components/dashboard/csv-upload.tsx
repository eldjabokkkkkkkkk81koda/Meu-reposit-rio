"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Upload, FileSpreadsheet, FileText, X, CheckCircle2, AlertCircle, Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { useStore } from "@/lib/store"
import {
  parseFile,
  parseSalesData,
  parseStockData,
  detectDataType,
  detectFileType,
} from "@/lib/file-parser"
import type { SaleRecord, StockItem } from "@/lib/types"

type UploadState = "idle" | "uploading" | "preview" | "success" | "error"
type DataType = "sales" | "stock"

interface PreviewData {
  headers: string[]
  rows: string[][]
  detectedType: DataType | "unknown"
  parsedSales?: SaleRecord[]
  parsedStock?: StockItem[]
}

export function CSVUpload() {
  const { setSales, setStock, alerts, setAlerts } = useStore()
  const [isDragOver, setIsDragOver] = useState(false)
  const [uploadState, setUploadState] = useState<UploadState>("idle")
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [previewData, setPreviewData] = useState<PreviewData | null>(null)
  const [selectedType, setSelectedType] = useState<DataType>("sales")
  const [error, setError] = useState<string | null>(null)
  const [progress, setProgress] = useState(0)

  const processFile = useCallback(async (file: File) => {
    console.log("[v0] processFile called:", { name: file.name, type: file.type, size: file.size })
    setError(null)
    setUploadState("uploading")
    setProgress(10)

    try {
      const fileType = detectFileType(file.name)
      console.log("[v0] File type from extension:", fileType)

      if (file.size > 10 * 1024 * 1024) {
        throw new Error("O arquivo deve ter no máximo 10MB.")
      }

      setProgress(30)
      const data = await parseFile(file)
      setProgress(60)

      if (data.length < 2) {
        throw new Error("O arquivo deve conter pelo menos um cabeçalho e uma linha de dados.")
      }

      const headers = data[0].map(String)
      const rows = data.slice(1, 6)
      const detectedType = detectDataType(headers)

      setProgress(80)

      const preview: PreviewData = {
        headers,
        rows: rows.map((row) => row.map(String)),
        detectedType,
      }

      if (detectedType === "sales" || detectedType === "unknown") {
        preview.parsedSales = parseSalesData(data)
      }
      if (detectedType === "stock" || detectedType === "unknown") {
        preview.parsedStock = parseStockData(data)
      }

      setPreviewData(preview)
      setSelectedType(detectedType === "unknown" ? "sales" : detectedType)
      setProgress(100)
      setUploadState("preview")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao processar arquivo")
      setUploadState("error")
    }
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    const droppedFile = e.dataTransfer.files[0]
    if (droppedFile) {
      setSelectedFile(droppedFile)
      processFile(droppedFile)
    }
  }, [processFile])

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      processFile(file)
    }
  }, [processFile])

  const confirmImport = () => {
    if (!previewData) return

    try {
      if (selectedType === "sales" && previewData.parsedSales) {
        setSales(previewData.parsedSales)
        const newAlert = {
          id: `import-sales-${Date.now()}`,
          type: "info" as const,
          title: "Dados importados",
          message: `${previewData.parsedSales.length} registros de vendas importados com sucesso.`,
          severity: "info" as const,
          timestamp: new Date().toISOString(),
          read: false,
        }
        setAlerts([...(alerts || []), newAlert])
      } else if (selectedType === "stock" && previewData.parsedStock) {
        setStock(previewData.parsedStock)
        const newAlert = {
          id: `import-stock-${Date.now()}`,
          type: "info" as const,
          title: "Dados importados",
          message: `${previewData.parsedStock.length} itens de estoque importados com sucesso.`,
          severity: "info" as const,
          timestamp: new Date().toISOString(),
          read: false,
        }
        setAlerts([...(alerts || []), newAlert])
      }

      setUploadState("success")
      setTimeout(() => resetUpload(), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao importar dados")
      setUploadState("error")
    }
  }

  const resetUpload = () => {
    setUploadState("idle")
    setSelectedFile(null)
    setPreviewData(null)
    setError(null)
    setProgress(0)
  }

  const getFileIcon = (filename: string) => {
    const ext = filename.split(".").pop()?.toLowerCase()
    if (ext === "xlsx" || ext === "xls") {
      return <FileSpreadsheet className="h-10 w-10 text-green-600" />
    }
    return <FileText className="h-10 w-10 text-blue-600" />
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5" />
          Upload de Dados
        </CardTitle>
        <CardDescription>
          Faça upload de arquivos CSV, TXT ou Excel (XLSX, XLS) com seus dados de vendas ou estoque.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {uploadState === "idle" && (
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              "relative flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 transition-colors",
              isDragOver
                ? "border-primary bg-primary/5"
                : "border-muted-foreground/25 hover:border-primary/50"
            )}
          >
            <input
              type="file"
              accept=".csv,.txt,.xlsx,.xls,text/csv,text/plain,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
              onChange={handleFileSelect}
              className="absolute inset-0 cursor-pointer opacity-0"
              aria-label="Upload de arquivo"
            />
            <div className="rounded-full bg-primary/10 p-4">
              <Upload className="h-8 w-8 text-primary" />
            </div>
            <p className="mt-4 text-sm font-medium">
              Arraste e solte seu arquivo aqui
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              ou clique para selecionar
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <Badge variant="secondary">.csv</Badge>
              <Badge variant="secondary">.txt</Badge>
              <Badge variant="secondary">.xlsx</Badge>
              <Badge variant="secondary">.xls</Badge>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Tamanho máximo: 10MB
            </p>
          </div>
        )}

        {uploadState === "uploading" && (
          <div className="space-y-4 py-8 text-center">
            <Loader2 className="mx-auto h-12 w-12 animate-spin text-primary" />
            <p className="text-sm font-medium">Processando arquivo...</p>
            <Progress value={progress} className="mx-auto max-w-xs" />
          </div>
        )}

        {uploadState === "preview" && previewData && selectedFile && (
          <div className="space-y-6">
            <div className="flex items-center justify-between rounded-lg bg-muted/50 p-4">
              <div className="flex items-center gap-3">
                {getFileIcon(selectedFile.name)}
                <div>
                  <p className="font-medium">{selectedFile.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {(selectedFile.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={resetUpload}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div>
              <p className="mb-2 text-sm font-medium">Selecione o tipo de dados:</p>
              <Tabs value={selectedType} onValueChange={(v) => setSelectedType(v as DataType)}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="sales">
                    Vendas
                    {previewData.detectedType === "sales" && (
                      <Badge variant="secondary" className="ml-2 text-xs">
                        Detectado
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="stock">
                    Estoque
                    {previewData.detectedType === "stock" && (
                      <Badge variant="secondary" className="ml-2 text-xs">
                        Detectado
                      </Badge>
                    )}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="sales" className="mt-4">
                  {previewData.parsedSales && previewData.parsedSales.length > 0 ? (
                    <div>
                      <p className="mb-2 text-sm text-muted-foreground">
                        {previewData.parsedSales.length} registros encontrados. Pré-visualização:
                      </p>
                      <div className="overflow-hidden rounded-lg border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Data</TableHead>
                              <TableHead>Produto</TableHead>
                              <TableHead>Categoria</TableHead>
                              <TableHead className="text-right">Qtd</TableHead>
                              <TableHead className="text-right">Valor</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {previewData.parsedSales.slice(0, 5).map((sale, i) => (
                              <TableRow key={i}>
                                <TableCell>{sale.date}</TableCell>
                                <TableCell>{sale.product}</TableCell>
                                <TableCell>{sale.category}</TableCell>
                                <TableCell className="text-right">{sale.quantity}</TableCell>
                                <TableCell className="text-right">R$ {sale.value.toFixed(2)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      Não foi possível detectar dados de vendas neste arquivo.
                    </p>
                  )}
                </TabsContent>

                <TabsContent value="stock" className="mt-4">
                  {previewData.parsedStock && previewData.parsedStock.length > 0 ? (
                    <div>
                      <p className="mb-2 text-sm text-muted-foreground">
                        {previewData.parsedStock.length} itens encontrados. Pré-visualização:
                      </p>
                      <div className="overflow-hidden rounded-lg border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>SKU</TableHead>
                              <TableHead>Nome</TableHead>
                              <TableHead>Categoria</TableHead>
                              <TableHead className="text-right">Qtd</TableHead>
                              <TableHead className="text-right">Preço</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {previewData.parsedStock.slice(0, 5).map((item, i) => (
                              <TableRow key={i}>
                                <TableCell>{item.sku}</TableCell>
                                <TableCell>{item.name}</TableCell>
                                <TableCell>{item.category}</TableCell>
                                <TableCell className="text-right">{item.quantity}</TableCell>
                                <TableCell className="text-right">R$ {item.price.toFixed(2)}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      Não foi possível detectar dados de estoque neste arquivo.
                    </p>
                  )}
                </TabsContent>
              </Tabs>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={resetUpload} className="flex-1">
                Cancelar
              </Button>
              <Button onClick={confirmImport} className="flex-1">
                Importar {selectedType === "sales" ? "Vendas" : "Estoque"}
              </Button>
            </div>
          </div>
        )}

        {uploadState === "success" && (
          <div className="space-y-4 py-8 text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-green-600" />
            <p className="text-lg font-medium text-green-600">Dados importados com sucesso!</p>
            <p className="text-sm text-muted-foreground">
              Você pode visualizar os dados no dashboard.
            </p>
            <Button variant="outline" onClick={resetUpload}>
              Fazer novo upload
            </Button>
          </div>
        )}

        {uploadState === "error" && (
          <div className="space-y-4 py-8 text-center">
            <AlertCircle className="mx-auto h-12 w-12 text-destructive" />
            <p className="text-lg font-medium text-destructive">Erro ao processar arquivo</p>
            <p className="text-sm text-muted-foreground">{error}</p>
            <Button variant="outline" onClick={resetUpload}>
              Tentar novamente
            </Button>
          </div>
        )}

        <div className="mt-6 rounded-lg bg-muted/50 p-4">
          <p className="text-sm font-medium">Colunas reconhecidas:</p>
          <div className="mt-3 grid gap-4 sm:grid-cols-2">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Vendas</p>
              <ul className="mt-1 space-y-1 text-xs text-muted-foreground">
                <li>data, date, dia</li>
                <li>produto, product, item</li>
                <li>categoria, category</li>
                <li>quantidade, quantity, qtd</li>
                <li>valor, value, preco, price</li>
                <li>canal, channel (opcional)</li>
              </ul>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Estoque</p>
              <ul className="mt-1 space-y-1 text-xs text-muted-foreground">
                <li>sku, codigo, code</li>
                <li>nome, name, produto</li>
                <li>categoria, category</li>
                <li>quantidade, quantity, estoque</li>
                <li>preco, price, valor</li>
                <li>fornecedor, supplier (opcional)</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
