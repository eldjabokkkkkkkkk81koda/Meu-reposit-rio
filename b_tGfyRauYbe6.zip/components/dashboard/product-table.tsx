"use client"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Search, ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react"
import type { ProductData } from "@/lib/types"
import { useState, useMemo } from "react"
import { cn } from "@/lib/utils"

interface ProductTableProps {
  products: ProductData[]
  isLoading?: boolean
}

type SortField = "name" | "totalRevenue" | "quantity" | "stock" | "margin"
type SortOrder = "asc" | "desc"

const ITEMS_PER_PAGE = 10

export function ProductTable({ products, isLoading }: ProductTableProps) {
  const [search, setSearch] = useState("")
  const [sortField, setSortField] = useState<SortField>("totalRevenue")
  const [sortOrder, setSortOrder] = useState<SortOrder>("desc")
  const [currentPage, setCurrentPage] = useState(1)
  const [categoryFilter, setCategoryFilter] = useState<string>("all")

  const categories = useMemo(() => {
    const cats = new Set(products.map((p) => p.category || "Outros"))
    return Array.from(cats)
  }, [products])

  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => {
        const matchesSearch = product.name
          .toLowerCase()
          .includes(search.toLowerCase())
        const matchesCategory =
          categoryFilter === "all" ||
          (product.category || "Outros") === categoryFilter
        return matchesSearch && matchesCategory
      })
      .sort((a, b) => {
        const aValue = a[sortField] ?? 0
        const bValue = b[sortField] ?? 0
        if (typeof aValue === "string" && typeof bValue === "string") {
          return sortOrder === "asc"
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue)
        }
        return sortOrder === "asc"
          ? (aValue as number) - (bValue as number)
          : (bValue as number) - (aValue as number)
      })
  }, [products, search, sortField, sortOrder, categoryFilter])

  const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE)
  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  )

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortOrder("desc")
    }
  }

  const getStockStatus = (stock: number) => {
    if (stock === 0) {
      return { label: "Sem estoque", variant: "destructive" as const }
    }
    if (stock < 10) {
      return { label: "Baixo", variant: "warning" as const }
    }
    return { label: "Normal", variant: "default" as const }
  }

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
    }).format(value)

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <div className="h-6 w-40 animate-pulse rounded bg-muted" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="h-10 w-full animate-pulse rounded bg-muted" />
            <div className="h-[400px] animate-pulse rounded bg-muted" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Produtos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex flex-col gap-4 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Buscar produto..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value)
                setCurrentPage(1)
              }}
              className="pl-9"
            />
          </div>
          <Select
            value={categoryFilter}
            onValueChange={(value) => {
              setCategoryFilter(value)
              setCurrentPage(1)
            }}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Categoria" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas categorias</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <Button
                    variant="ghost"
                    onClick={() => handleSort("name")}
                    className="-ml-4 h-8 gap-1"
                  >
                    Produto
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button
                    variant="ghost"
                    onClick={() => handleSort("totalRevenue")}
                    className="-mr-4 h-8 gap-1"
                  >
                    Receita
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button
                    variant="ghost"
                    onClick={() => handleSort("quantity")}
                    className="-mr-4 h-8 gap-1"
                  >
                    Vendas
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button
                    variant="ghost"
                    onClick={() => handleSort("stock")}
                    className="-mr-4 h-8 gap-1"
                  >
                    Estoque
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">
                  <Button
                    variant="ghost"
                    onClick={() => handleSort("margin")}
                    className="-mr-4 h-8 gap-1"
                  >
                    Margem
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedProducts.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={6}
                    className="h-24 text-center text-muted-foreground"
                  >
                    Nenhum produto encontrado.
                  </TableCell>
                </TableRow>
              ) : (
                paginatedProducts.map((product) => {
                  const stockStatus = getStockStatus(product.stock)
                  return (
                    <TableRow key={product.id}>
                      <TableCell className="font-medium">
                        <div>
                          <p>{product.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {product.category || "Sem categoria"}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        {formatCurrency(product.totalRevenue)}
                      </TableCell>
                      <TableCell className="text-right">
                        {product.quantity.toLocaleString("pt-BR")}
                      </TableCell>
                      <TableCell className="text-right">
                        {product.stock.toLocaleString("pt-BR")}
                      </TableCell>
                      <TableCell
                        className={cn(
                          "text-right font-medium",
                          (product.margin ?? 0) >= 20
                            ? "text-success"
                            : (product.margin ?? 0) >= 10
                              ? "text-foreground"
                              : "text-destructive"
                        )}
                      >
                        {(product.margin ?? 0).toFixed(1)}%
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            stockStatus.variant === "warning"
                              ? "secondary"
                              : stockStatus.variant
                          }
                          className={cn(
                            stockStatus.variant === "warning" &&
                              "bg-warning text-warning-foreground"
                          )}
                        >
                          {stockStatus.label}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </div>

        {totalPages > 1 && (
          <div className="mt-4 flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Mostrando {(currentPage - 1) * ITEMS_PER_PAGE + 1} a{" "}
              {Math.min(currentPage * ITEMS_PER_PAGE, filteredProducts.length)}{" "}
              de {filteredProducts.length} produtos
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
                <span className="sr-only">Página anterior</span>
              </Button>
              <span className="text-sm">
                Página {currentPage} de {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() =>
                  setCurrentPage((p) => Math.min(totalPages, p + 1))
                }
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
                <span className="sr-only">Próxima página</span>
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
