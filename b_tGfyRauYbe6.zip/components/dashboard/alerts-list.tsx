"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Package,
  X,
  Bell,
} from "lucide-react"
import type { Alert } from "@/lib/types"
import { cn } from "@/lib/utils"

interface AlertsListProps {
  alerts: Alert[]
  onDismiss?: (id: string) => void
  showAll?: boolean
}

const alertIcons = {
  "low-stock": Package,
  "sales-drop": TrendingDown,
  "high-demand": TrendingUp,
  "price-alert": AlertTriangle,
} as const

const alertColors = {
  critical: "bg-destructive text-destructive-foreground",
  warning: "bg-warning text-warning-foreground",
  info: "bg-primary text-primary-foreground",
} as const

export function AlertsList({ alerts, onDismiss, showAll = false }: AlertsListProps) {
  const visibleAlerts = showAll
    ? alerts
    : alerts.filter((a) => !a.dismissed).slice(0, 5)

  if (visibleAlerts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Alertas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="rounded-full bg-muted p-3">
              <Bell className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="mt-4 text-sm font-medium">Nenhum alerta no momento</p>
            <p className="text-sm text-muted-foreground">
              Você será notificado quando houver algo importante.
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Alertas
          {!showAll && alerts.filter((a) => !a.dismissed).length > 0 && (
            <Badge variant="destructive" className="ml-auto">
              {alerts.filter((a) => !a.dismissed).length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {visibleAlerts.map((alert) => {
            const Icon = alertIcons[alert.type] || AlertTriangle
            return (
              <div
                key={alert.id}
                className={cn(
                  "flex items-start gap-3 rounded-lg border p-3 transition-colors",
                  alert.dismissed && "opacity-60"
                )}
              >
                <div
                  className={cn(
                    "rounded-full p-2",
                    alertColors[alert.severity]
                  )}
                >
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{alert.title}</p>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {alert.message}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {new Date(alert.createdAt).toLocaleDateString("pt-BR", {
                      day: "2-digit",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
                {onDismiss && !alert.dismissed && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 shrink-0"
                    onClick={() => onDismiss(alert.id)}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Dispensar alerta</span>
                  </Button>
                )}
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
