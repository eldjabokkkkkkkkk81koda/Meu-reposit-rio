"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Sparkles, RefreshCw, Lightbulb, TrendingUp, AlertTriangle } from "lucide-react"
import type { Insight } from "@/lib/types"
import { cn } from "@/lib/utils"

interface AIInsightsProps {
  insights: Insight[]
  isLoading?: boolean
  onRefresh?: () => void
}

const insightIcons = {
  opportunity: Lightbulb,
  trend: TrendingUp,
  warning: AlertTriangle,
  recommendation: Sparkles,
} as const

const priorityColors = {
  high: "bg-destructive/10 text-destructive border-destructive/20",
  medium: "bg-warning/10 text-warning-foreground border-warning/20",
  low: "bg-muted text-muted-foreground border-muted",
} as const

export function AIInsights({ insights, isLoading, onRefresh }: AIInsightsProps) {
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Insights com IA
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div
                key={i}
                className="animate-pulse rounded-lg border p-4"
              >
                <div className="flex items-start gap-3">
                  <div className="h-10 w-10 rounded-full bg-muted" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 w-3/4 rounded bg-muted" />
                    <div className="h-3 w-full rounded bg-muted" />
                    <div className="h-3 w-2/3 rounded bg-muted" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          Insights com IA
        </CardTitle>
        {onRefresh && (
          <Button variant="ghost" size="sm" onClick={onRefresh}>
            <RefreshCw className="mr-2 h-4 w-4" />
            Atualizar
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {insights.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="rounded-full bg-primary/10 p-3">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <p className="mt-4 text-sm font-medium">
              Nenhum insight disponível
            </p>
            <p className="text-sm text-muted-foreground">
              Faça upload de dados para gerar insights automáticos.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {insights.map((insight) => {
              const Icon = insightIcons[insight.type] || Sparkles
              return (
                <div
                  key={insight.id}
                  className={cn(
                    "rounded-lg border p-4 transition-colors hover:bg-accent/50",
                    priorityColors[insight.priority]
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className="rounded-full bg-background p-2 shadow-sm">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-medium">{insight.title}</p>
                        <Badge variant="outline" className="text-xs">
                          {insight.type === "opportunity" && "Oportunidade"}
                          {insight.type === "trend" && "Tendência"}
                          {insight.type === "warning" && "Alerta"}
                          {insight.type === "recommendation" && "Recomendação"}
                        </Badge>
                      </div>
                      <p className="mt-1 text-sm opacity-90">
                        {insight.description}
                      </p>
                      {insight.impact && (
                        <p className="mt-2 text-xs font-medium">
                          Impacto estimado: {insight.impact}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
